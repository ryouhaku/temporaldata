^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rviz_animated_view_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2014-05-20)
------------------
* force package version
* add demo launch file
* update urls in package.xml
* minor style fix
* update plugin macro
* apply catkin_lint
* catkinized
* minor change
* separating...
* separating packages
* preparing for first release
* removes CameraPlacementTrajectory from everything
* removes CameraPlacementTrajectory
* fixes singularity; simplifies up-vector
* splits up msgs and plugin
* moving from visualization trunk
* Contributors: Adam Leeper, Sachin Chitta, aleeper
