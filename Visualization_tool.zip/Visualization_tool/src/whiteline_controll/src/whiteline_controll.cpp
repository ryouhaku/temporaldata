/*
 *  Copyright (c) 2015, Nagoya University
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  * Neither the name of Autoware nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <ros/console.h>
#include <visualization_msgs/MarkerArray.h>
#include <vector_map/vector_map.h>
#include <jsk_recognition_msgs/BoundingBox.h>
#include <jsk_recognition_msgs/BoundingBoxArray.h>
#include <geometry_msgs/TwistStamped.h>
#include <geometry_msgs/PoseStamped.h>
#include <sensor_msgs/JointState.h>
#include <math.h>
#include <std_msgs/Float32.h>
#include <tf/tf.h>
#include <whitewall_msgs/Whitewall.h>
#include <tf/transform_datatypes.h>

using vector_map::VectorMap;
using vector_map::Category;
using vector_map::Color;
using vector_map::Key;
using vector_map::Line;
using vector_map::Area;
using vector_map::WhiteLine;
using vector_map::WhiteLineArray;
using vector_map::isValidMarker;

jsk_recognition_msgs::BoundingBoxArray whiteline_array;
visualization_msgs::MarkerArray visualize_array;
ros::Publisher whiteline_wall_pub;
ros::Publisher velocity_pub, roll_pub, pitch_pub, yaw_pub;

double length;
double thickness;
double height;

namespace
{
visualization_msgs::Marker createLinkedLineMarker(const std::string& ns, int id, Color color, const VectorMap& vmap,
                                                  const Line& line)
{
  Area area;
  area.aid = 1; // must set valid aid
  area.slid = line.lid;
  return createAreaMarker(ns, id, color, vmap, area);
}

visualization_msgs::MarkerArray createWhiteLineMarkerArray(const VectorMap& vmap, Color white_color,
                                                           Color yellow_color)
{
  visualization_msgs::MarkerArray marker_array;
  int id = 0;
  for (const auto& white_line : vmap.findByFilter([](const WhiteLine& white_line){return true;}))
  {
    if (white_line.lid == 0)
    {
      ROS_ERROR_STREAM("[createWhiteLineMarkerArray] invalid white_line: " << white_line);
      continue;
    }
    if (white_line.type == WhiteLine::DASHED_LINE_BLANK) // if invisible line
      continue;

    Line line = vmap.findByKey(Key<Line>(white_line.lid));
    if (line.lid == 0)
    {
      ROS_ERROR_STREAM("[createWhiteLineMarkerArray] invalid line: " << line);
      continue;
    }

    if (line.blid == 0) // if beginning line
    {
      visualization_msgs::Marker marker;
      switch (white_line.color)
      {
      case 'W':
        marker = createLinkedLineMarker("white_line", id++, white_color, vmap, line);
        break;
      case 'Y':
        marker = createLinkedLineMarker("white_line", id++, yellow_color, vmap, line);
        break;
      default:
        ROS_ERROR_STREAM("[createWhiteLineMarkerArray] unknown white_line.color: " << white_line);
        continue;
      }
      // XXX: The visualization_msgs::Marker::LINE_STRIP is difficult to deal with white_line.width.
      if (isValidMarker(marker))
        marker_array.markers.push_back(marker);
      else
        ROS_ERROR_STREAM("[createWhiteLineMarkerArray] failed createLinkedLineMarker: " << line);
    }
  }
  return marker_array;
}

}

void make_whiteline_boundingbox(const visualization_msgs::MarkerArray& msg){
	jsk_recognition_msgs::BoundingBoxArray array;
	int j = 0;
	int odds = 0;
  double x,y,z;

	for(auto& marker : msg.markers){
		if(marker.points.size()%2 == 1) odds++;
		if (!(marker.color.r == 1.0 && marker.color.g == 1.0 && marker.color.b == 1.0)) continue;
		for(int i = 0; i < marker.points.size()-1; i+=2){
			jsk_recognition_msgs::BoundingBox box;
      x = marker.points[i].x - marker.points[i+1].x;
      y = marker.points[i].y - marker.points[i+1].y;
      z = marker.points[i].z - marker.points[i+1].z;
			box.header = marker.header;
			box.pose.position.x = (marker.points[i].x + marker.points[i+1].x)/2.0;
      box.pose.position.y = (marker.points[i].y + marker.points[i+1].y)/2.0;
			box.pose.position.z = (marker.points[i].z + marker.points[i+1].z)/2.0;
			j++;
			box.dimensions.x = length * sqrt(x*x + y*y + z*z);
			box.dimensions.y = thickness;
			box.dimensions.z = height;
      box.value = sqrt(x*x + y*y + z*z);

      tf::Quaternion q1(0, 0, (y / std::fabs(y)) * sqrt((1 - x/sqrt(x*x + y*y))/2.0), sqrt((1 + x/sqrt(x*x + y*y))/2.0) );

      double qx,qy;
      if(z > 0){
        qx = (y/sqrt(x*x + y*y)) * sqrt((1 - sqrt(x*x + y*y)/sqrt(x*x + y*y + z*z))/2.0);
        qy = (-x/sqrt(x*x + y*y)) * sqrt((1 - sqrt(x*x + y*y)/sqrt(x*x + y*y + z*z))/2.0);
      }else{
        qx = (-y/sqrt(x*x + y*y)) * sqrt((1 - sqrt(x*x + y*y)/sqrt(x*x + y*y + z*z))/2.0);
        qy = (x/sqrt(x*x + y*y)) * sqrt((1 - sqrt(x*x + y*y)/sqrt(x*x + y*y + z*z))/2.0);
      }
      tf::Quaternion q2(qx, qy,
                        0,
                        sqrt((1 + sqrt(x*x + y*y)/sqrt(x*x + y*y + z*z))/2.0));
      tf::Quaternion q_out;
      q_out = q2 * q1;
      quaternionTFToMsg(q_out, box.pose.orientation);
      array.boxes.push_back(box);
		}
	}
	array.header = msg.markers[0].header;
	whiteline_array = array;
}

void wall_parameter_callback(const whitewall_msgs::Whitewall& msg)
{
  jsk_recognition_msgs::BoundingBoxArray array;
  double length2 = msg.length;
  double thickness2 = msg.thickness;
  double height2 = msg.height;

  for(auto& box_orig: whiteline_array.boxes){
    jsk_recognition_msgs::BoundingBox box;
    box.header = box_orig.header;
		box.pose.position.x = box_orig.pose.position.x;
    box.pose.position.y = box_orig.pose.position.y;
		box.pose.position.z = box_orig.pose.position.z + std::fabs(height2)/2.0;
    box.pose.orientation.x = box_orig.pose.orientation.x;
    box.pose.orientation.y = box_orig.pose.orientation.y;
    box.pose.orientation.z = box_orig.pose.orientation.z;
    box.pose.orientation.w = box_orig.pose.orientation.w;
    box.dimensions.x = std::fabs(length2) * box_orig.value;
		box.dimensions.y = std::fabs(thickness2);
		box.dimensions.z = std::fabs(height2);

    array.boxes.push_back(box);
  }
  array.header = whiteline_array.header;
  whiteline_wall_pub.publish(array);
}

int num_lines(visualization_msgs::Marker marker){
	return marker.points.size()/2;
}

void drip_whiteline_bounding_box(const visualization_msgs::MarkerArray& msg){
	int count = 0;
	for (auto& marker : msg.markers){
		if(marker.ns == "white_line"){
			count += num_lines(marker);
      visualize_array.markers.push_back(marker);
		}
	}
	make_whiteline_boundingbox(visualize_array);
}

void velocity_callback(const geometry_msgs::TwistStampedConstPtr& msg)
{
  std_msgs::Float32 v;
  v.data = msg->twist.linear.x;
  velocity_pub.publish(v);
}

void ndt_pose_callback(const geometry_msgs::PoseStampedConstPtr& msg)
{
  std_msgs::Float32 roll,pitch,yaw;
  double r,p,y;
  tf::Quaternion q(msg->pose.orientation.x, msg->pose.orientation.y, msg->pose.orientation.z, msg->pose.orientation.w);
  tf::Matrix3x3 m(q);
  m.getRPY(r,p,y);
  roll.data = r;
  pitch.data = p;
  yaw.data = y;
  roll_pub.publish(roll);
  pitch_pub.publish(pitch);
  yaw_pub.publish(yaw);
}

static ros::Publisher rostime_pub;
static std_msgs::Float32 rostime;

int main(int argc, char **argv)
{
	ros::init(argc, argv, "whiteline_wall");
	printf("---whiteline_controll---\n");
	ros::NodeHandle n;
  ros::NodeHandle private_nh("~");

  private_nh.getParam("length", length);
  private_nh.getParam("thickness", thickness);
  private_nh.getParam("height", height);
  //private_nh.getParam("init_z", g_ini_z);

	whiteline_wall_pub = n.advertise<jsk_recognition_msgs::BoundingBoxArray>("/whiteline_wall",1,true);

	//ros::Subscriber white_lines = n.subscribe("vector_map_info/white_line",1 , whiteline_bounding_box);
	ros::Subscriber marker_array = n.subscribe("vector_map",1 , drip_whiteline_bounding_box);

	vector_map::category_t category = Category::WHITE_LINE;
  rostime_pub = n.advertise<std_msgs::Float32>("/rostime2", 10);

  ros::Subscriber velocity_sub = n.subscribe("/current_velocity",1,velocity_callback);
  ros::Subscriber ndt_pose_sub = n.subscribe("/ndt_pose",1 , ndt_pose_callback);
  ros::Subscriber wall_parameter_sub = n.subscribe("/wall_parameter",1,wall_parameter_callback);
  velocity_pub = n.advertise<std_msgs::Float32>("/current_velocity_float", 10, true);
  roll_pub = n.advertise<std_msgs::Float32>("/roll_float", 10, true);
  pitch_pub = n.advertise<std_msgs::Float32>("/pitch_float", 10, true);
  yaw_pub = n.advertise<std_msgs::Float32>("/yaw_float", 10, true);

  ros::Time now_time =ros::Time::now();
  printf("ROSTime2: %f\n",now_time.sec + now_time.nsec/1000000000.0);
  rostime.data = now_time.sec + now_time.nsec/1000000000.0;
  rostime_pub.publish(rostime);


	ros::spin();

	return EXIT_SUCCESS;
}
