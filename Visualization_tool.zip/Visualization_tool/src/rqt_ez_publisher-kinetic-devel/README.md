rqt_ez_publisher
================

read http://wiki.ros.org/rqt_ez_publisher

