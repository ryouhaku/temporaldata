
"use strict";

let CameraPlacement = require('./CameraPlacement.js');

module.exports = {
  CameraPlacement: CameraPlacement,
};
