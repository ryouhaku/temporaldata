import tf, sys
from geometry_msgs.msg import Vector3, Quaternion

args = sys.argv
def quaternion_to_euler(quaternion):
    """Convert Quaternion to Euler Angles
    quarternion: geometry_msgs/Quaternion
    euler: geometry_msgs/Vector3
    """
    e = tf.transformations.euler_from_quaternion((quaternion.x, quaternion.y, quaternion.z, quaternion.w))
    return Vector3(x=e[0], y=e[1], z=e[2])

x=float(args[1])
y=float(args[2])
z=float(args[3])
w=float(args[4])

a = Quaternion(x,y,z,w) 
b = quaternion_to_euler(a)
print('roll: ' + str(b.x))
print('pitch: ' + str(b.y))
print('yaw: ' + str(b.z))


