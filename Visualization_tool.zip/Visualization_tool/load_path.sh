#!/usr/bin/env bash
export ROS_PACKAGE_PATH=$ROS_PACKAGE_PATH:~/Autoware/ros/src:~/synesthesias/nihonseiki/src
